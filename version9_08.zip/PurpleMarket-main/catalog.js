const API = {
    BASE_URL: 'http://locallocalhost:8000/api/',
    ENDPOINTS: {
        PRODUCTS: 'products/',
        FAVORITES: 'favorites/',
        CART: 'cart/',
        CART_ITEMS: 'cart-items/',
        CATEGORIES: 'categories/',
        SEARCH: 'search/'
    },

    HEADERS: {
        'Content-Type': 'aplication/json',
    }
};

const state = {
    products: [],

    pagination: {
        currentPage: 1,
        totalPages: 1,
        totalItems: 0,
        itemsPerPage: 8
    },

    favorites: new Set(),

    cart: new Map(),

    viewMode: 'grid',

    sortBy: 'popular',

    searchQery: '',

    filters: {
        categories: [],
        priceMin: null,
        priceMax: null,
        rating: null,
        inStock: false
    },

    isLoading: false
};

const DOM = {
    // контейнеры
    grid: document.getElementById('productsGrid'),
    filters: document.getElementById('filtersPanel'),
    pagination: document.getElementById('pagination'),
    pageNumbers: document.getElementById('pageNumbers'),


    // Кнопки
    gridViewBtn: document.getElementById('gridViewBtn'),
    listViewBtn: document.getElementById('listViewBtn'),
    prevPageBtn: document.getElementById('prevPageBtn'),
    nextPageBtn: document.getElementById('nextPageBtn'),
    applyFiltersBtn: document.getElementById('applyFiltersBtn'),
    resetFiltersBtn: document.getElementById('resetFiltersBtn'),

    // Поля ввода
    searchInput: document.getElementById('.search'),
    priceMin: document.getElementById('priceMin'),
    priceMax: document.getElementById('priceMax'),
    inStockOnly: document.getElementById('inStockOnly'),

    // Счётчики и индикаторы
    itemCount: document.getElementById('itemCount'),
    cartBadge: document.getElementById('cartBadge'),

    // Группы фильтров
    categoryChecks: document.querySelectorAll('#categoryFilters input[type="checkbox"]'),
    ratingRadios: document.querySelectorAll('#ratingFilters input[type="radio"]'),
    sortSelect: document.getElementById('sortSelect')
};

async function apiRequest(endpoint, options = {}) {
    const url = API.BASE_URL + endpoint;
    const config = {
        headers: API.HEADERS,
        ...options
    }; 
    
    try {
        const response = await fetch(url, config);

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || 'Ошибка ${response.status}: ${respose.statusText}');
    
            
        }

        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

/**
 * Загрузка товаров с пагинацией, фильтрацией и сортировкой.
 * 
 * @param {Object} params - Параметры запроса
 * @param {number} params.page - Номер страницы
 * @param {string} params.sort - Поле сортировки
 * @param {string} params.search - Поисковый запрос
 * @param {Array} params.categories - Массив категорий
 * @param {number} params.price_min - Минимальная цена
 * @param {number} params.price_max - Максимальная цена
 * @param {number} params.rating - Минимальный рейтинг
 * @param {boolean} params.in_stock - Только в наличии
 */

async function fetchProducts(params = {}) {
    state.isLoading = true;
    
    const queryParams = new URLSearchParams();

    if (params.page) queryParams.append('page', params.page);
    if (params.per_page) queryParams.append('per_page', params.per_page);

    if (params.sort) queryParams.append('sort', params.sort);

    if (params.search) queryParams.append('search', params.search);

    if (params.categories && params.categories.length) {
        queryParams.append('categories', params.categories.join(','));
    }
    if (params.price_min) queryParams.append('price_min', params.price_min);
    if (params.price_max) queryParams.append('price_max', params.price_max);
    if (params.rating) queryParams.append('rating', params.rating);
    if (params.in_stock) queryParams.append('in_stock', 'true');

    try {
        const url = API.ENDPOINTS.PRODUCTS + '?' + queryParams.toString();
        const data = await apiRequest(url);

        state.products = data.results || data.items || data;
        state.pagination.totalItems = data.count || data.total || state.products.length;
        state.pagination.currentPage = params.page || 1;
        state.pagination.totalPages = Math.ceil(state.pagination.totalItems / (params.per_page || 8));
        state.pagination.itemsPerPage = params.per_page || 8;

        return state.products;
        
    } catch (error) {
        console.error('Ошибка загрузки товаров:', error);
        showNotification('Не удалось загрузить товары', 'error');
        return [];
    } finally {
        state.isLoading = false;
    }
}

async function fetchFavorites() {
    try {
        const data = await apiRequest(API.ENDPOINTS.FAVORITES);

        const ids = data.map(item => item.id || item);
        state.favorites = new Set(ids);
        return state.favorites;
    } catch (error) {
        console.error('Ошибка загрузки избранного:', error);
        return new Set();
    }
}
/**
@param {number} productId - ID товара
@param {boolean} add - true = добавить, false = удалить
*/
async function toggleFavorite(productId, add) {
    try {
        if (add) {
            await apiRequest(API.ENDPOINTS.FAVORITES, {
                method: 'POST',
                body: JSON.stringify({product_id: productId})
            });
        } else {
            await apiRequest(`${API.ENDPOINTS.FAVORITES}${productId}/`, {
                method: 'DELETE'
            });
        }
        return true;
    } catch (error) {
        console.error('Ошибка изменения избранного:', error);
        showNotification('Не удалось обновить избранное', 'error');
        return false;
    }
}

async function fetchCart() {
    try {
        const data = await apiRequest(API.ENDPOINTS.CART_ITEMS);
        state.cart = new Map(data.map(item => [item.product_id, item.quantity]));
        return state.cart;
    } catch (error) {
        console.error('Ошибка загрузки корзины:', error);
        return new Map();
    }
}

/**
 * @param {number} productId - ID товара
 * @param {number} quantity
 */
async function addToCart(productId, quantity = 1) {
    try {
        await apiRequest(API.ENDPOINTS.CART_ITEMS, {
            method: 'POST',
            body: JSON.stringify({product_id: productId, quantity})
        });

        if (state.cart.has(productId)) {
            state.cart.set(productId, state.cart.get(productId) + quantity);
        } else {
            state.cart.set(productId, quantity);
        }

        return true;
    } catch (error) {
        console.error('Ошибка добавления в корзину:', error);
        showNotification('Не удалось добавить товар в корзину', 'error');
        return false;
    }
}

/**
 * @param {number} productId
 * @param {number} quantity
 */

async function removeFromCart(productId, quantity = null) {
    try {
        const currentQuantity = state.cart.get(productId) || 0;

        if (quantity === null || quantity >= currentQuantity) {
            await apiRequest(`${API.ENDPOINTS.CART_ITEMS}${productId}/`, {
                method: 'DELETE'
            });
            state.cart.delete(productId);
        } else {
            await apiRequest(`${API.ENDPOINTS.CART_ITEMS}${productId}/`, {
                method: 'PATCH',
                body: JSON.stringify({quantity: currentQuantity - quantity})
            });
            state.cart.set(productId, currentQuantity - quantity);
        }

        return true;
    } catch (error) {
        console.error('Ошибка загрузки категорий:', error);
        return [];
    }
}

async function loadAllData() {
    showLoader(true);

    try {
        const [products, favorites, cart, categories] = await Promise.all([
            fetchProducts(buildQueryParams()),
            fetchFavites(),
            fetchCart(),
            fetchCategories()
        ]);

        
    }
}